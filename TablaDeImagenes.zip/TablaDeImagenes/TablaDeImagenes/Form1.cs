using System;
using System.Collections.Generic;
using System.Drawing;
using System.Net;
using System.Windows.Forms;

namespace bienvenida{

}

namespace TablaDeImagenes
{

    public partial class Form1 : Form
    {

        private TableLayoutPanel tableLayoutPanel;
        private ComboBox comboBox;
        private Dictionary<string, List<string>> categoryImageUrls = new Dictionary<string, List<string>>();
        private string[] imageUrls = new string[]
        {
            "https://c8.alamy.com/compes/2jt6t27/sematario-para-mascotas-novela-de-stephen-king-1983-2jt6t27.jpg",
            "https://hips.hearstapps.com/hmg-prod/images/poster-peliculas-terror-2019-prodigy-1578395572.jpg",
            "https://m.media-amazon.com/images/I/61m2z08sfZL._AC_UF894,1000_QL80_.jpg",
            "https://s3.amazonaws.com/virginia.webrand.com/virginia/344/UAr1p9YQzP4/9c15565d8122283e05d689cc4a5ce0fe.jpg?1691701400"
        };

        public Form1()
        {
            this.ClientSize = new Size(800, 600);
            InitializeComponent();

            categoryImageUrls["Drama"] = new List<string>
            {
                "https://pics.filmaffinity.com/El_resplandor-905473224-large.jpg",
                "https://img.wattpad.com/82ed46b2c99e590fb4d0e967d954ad1d8705278b/68747470733a2f2f73332e616d617a6f6e6177732e636f6m2f776174747061642d6d656469612d736572766963652f53746f7279496d6167652f68374c387663374a5ZVjNWYxOGIyNjNlMDVkNjg5Y2M0YTVjZTBlZmU.jpg",
                "https://c8.alamy.com/compes/2jt6t27/sematario-para-mascotas-novela-de-stephen-king-1983-2jt6t27.jpg",
                "https://hips.hearstapps.com/hmg-prod/images/poster-peliculas-terror-2019-prodigy-1578395572.jpg",
                "https://m.media-amazon.com/images/I/61m2z08sfZL._AC_UF894,1000_QL80_.jpg",
                "https://s3.amazonaws.com/virginia.webrand.com/virginia/344/UAr1p9YQzP4/9c15565d8122283e05d689cc4a5ce0fe.jpg?1691701400"
            };

            categoryImageUrls["Accion"] = new List<string>
            {
                "https://cdn.superaficionados.com/imagenes/1-las-mejores-peliculas-de-drama-el-padrino-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/2-las-mejores-peliculas-de-drama-el-ciudadano-kane-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/3-las-mejores-peliculas-de-drama-la-lista-de-schindler-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/4-las-mejores-peliculas-de-drama-boyhood-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/5-las-mejores-peliculas-de-drama-lo-que-el-viento-se-llevo-cke.jpg"
            };

            categoryImageUrls["Terror"] = new List<string>
            {
                "https://cdn.superaficionados.com/imagenes/1-las-mejores-peliculas-de-drama-el-padrino-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/2-las-mejores-peliculas-de-drama-el-ciudadano-kane-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/3-las-mejores-peliculas-de-drama-la-lista-de-schindler-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/4-las-mejores-peliculas-de-drama-boyhood-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/5-las-mejores-peliculas-de-drama-lo-que-el-viento-se-llevo-cke.jpg"
            };

            categoryImageUrls["Suspenso"] = new List<string>
            {
                "https://cdn.superaficionados.com/imagenes/1-las-mejores-peliculas-de-drama-el-padrino-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/2-las-mejores-peliculas-de-drama-el-ciudadano-kane-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/3-las-mejores-peliculas-de-drama-la-lista-de-schindler-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/4-las-mejores-peliculas-de-drama-boyhood-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/5-las-mejores-peliculas-de-drama-lo-que-el-viento-se-llevo-cke.jpg"
            };

            categoryImageUrls["Comedia"] = new List<string>
            {
                "https://cdn.superaficionados.com/imagenes/1-las-mejores-peliculas-de-drama-el-padrino-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/2-las-mejores-peliculas-de-drama-el-ciudadano-kane-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/3-las-mejores-peliculas-de-drama-la-lista-de-schindler-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/4-las-mejores-peliculas-de-drama-boyhood-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/5-las-mejores-peliculas-de-drama-lo-que-el-viento-se-llevo-cke.jpg"
            };

            categoryImageUrls["Animados"] = new List<string>
            {
                "https://cdn.superaficionados.com/imagenes/1-las-mejores-peliculas-de-drama-el-padrino-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/2-las-mejores-peliculas-de-drama-el-ciudadano-kane-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/3-las-mejores-peliculas-de-drama-la-lista-de-schindler-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/4-las-mejores-peliculas-de-drama-boyhood-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/5-las-mejores-peliculas-de-drama-lo-que-el-viento-se-llevo-cke.jpg"
            };
            categoryImageUrls["Romanticas"] = new List<string>
            {

                "https://cdn.superaficionados.com/imagenes/4-las-mejores-peliculas-de-drama-boyhood-cke.jpg",
                "https://cdn.superaficionados.com/imagenes/5-las-mejores-peliculas-de-drama-lo-que-el-viento-se-llevo-cke.jpg"
            };

            CrearTablaDeBotones();
            CrearComboBoxCategorias();
        }

        private void CrearTablaDeBotones()
        {
            tableLayoutPanel = new TableLayoutPanel();
            tableLayoutPanel.Dock = DockStyle.Fill;
            tableLayoutPanel.AutoScroll = true;
            tableLayoutPanel.RowCount = 5;
            tableLayoutPanel.ColumnCount = 5;

            for (int i = 0; i < 25; i++)
            {
                Button imageButton = new Button();
                imageButton.Dock = DockStyle.Fill;
                imageButton.BackgroundImageLayout = ImageLayout.Stretch;
                imageButton.Size = new Size(200, 300);

                if (i < imageUrls.Length)
                {
                    string imageUrl = imageUrls[i];

                    using (WebClient webClient = new WebClient())
                    {
                        try
                        {
                            byte[] imageBytes = webClient.DownloadData(imageUrl);
                            using (var ms = new System.IO.MemoryStream(imageBytes))
                            {
                                Image img = Image.FromStream(ms);
                                if (img != null)
                                {
                                    imageButton.BackgroundImage = img;
                                }
                                else
                                {
                                    MessageBox.Show("La imagen no se ha cargado correctamente.");
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error al cargar la imagen: {ex.Message}");
                        }
                    }

                    imageButton.Click += (sender, e) =>
                    {
                        MessageBox.Show("Ventana emergente de pelicula.");
                    };
                }

                tableLayoutPanel.Controls.Add(imageButton);
            }

            this.Controls.Add(tableLayoutPanel);
        }

        private void CrearComboBoxCategorias()
        {
            comboBox = new ComboBox();
            comboBox.Dock = DockStyle.Top;
            comboBox.Items.Add("Seleccione la categor�a de inter�s");
            comboBox.Items.AddRange(new string[] { "Drama", "Suspenso", "Accion", "Terror", "Comedia", "Animados","Romanticas" });
            comboBox.SelectedIndex = 0;
            comboBox.SelectedIndexChanged += ComboBox_SelectedIndexChanged;
            this.Controls.Add(comboBox);
        }

        private void ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCategory = comboBox.SelectedItem.ToString();
            tableLayoutPanel.Controls.Clear();

            if (selectedCategory == "Seleccione la categor�a de inter�s")
            {
                foreach (string imageUrl in imageUrls)
                {
                    Button imageButton = new Button();
                    imageButton.Dock = DockStyle.Fill;
                    imageButton.BackgroundImageLayout = ImageLayout.Stretch;
                    imageButton.Size = new Size(200, 300);

                    using (WebClient webClient = new WebClient())
                    {
                        try
                        {
                            byte[] imageBytes = webClient.DownloadData(imageUrl);
                            using (var ms = new System.IO.MemoryStream(imageBytes))
                            {
                                Image img = Image.FromStream(ms);
                                if (img != null)
                                {
                                    imageButton.BackgroundImage = img;
                                }
                                else
                                {
                                    MessageBox.Show("La imagen no se ha cargado correctamente.");
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error al cargar la imagen: {ex.Message}");
                        }
                    }

                    imageButton.Click += (btnSender, btnE) =>
                    {
                        MessageBox.Show("Haz hecho clic en la imagen.");
                    };

                    tableLayoutPanel.Controls.Add(imageButton);
                }
            }
            else
            {
                if (categoryImageUrls.ContainsKey(selectedCategory))
                {
                    List<string> imageUrls = categoryImageUrls[selectedCategory];

                    foreach (string imageUrl in imageUrls)
                    {
                        Button imageButton = new Button();
                        imageButton.Dock = DockStyle.Fill;
                        imageButton.BackgroundImageLayout = ImageLayout.Stretch;
                        imageButton.Size = new Size(200, 300);

                        using (WebClient webClient = new WebClient())
                        {
                            try
                            {
                                byte[] imageBytes = webClient.DownloadData(imageUrl);
                                using (var ms = new System.IO.MemoryStream(imageBytes))
                                {
                                    Image img = Image.FromStream(ms);
                                    if (img != null)
                                    {
                                        imageButton.BackgroundImage = img;
                                    }
                                    else
                                    {
                                        MessageBox.Show("La imagen no se ha cargado correctamente.");
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Error al cargar la imagen: {ex.Message}");
                            }
                        }

                        imageButton.Click += (btnSender, btnE) =>
                        {
                            MessageBox.Show("Haz hecho clic en la imagen.");
                        };

                        tableLayoutPanel.Controls.Add(imageButton);
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
